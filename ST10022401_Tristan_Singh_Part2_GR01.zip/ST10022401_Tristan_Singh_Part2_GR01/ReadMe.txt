AgriEnergy Part 2 App

Table of Contents
- [Introduction]
- [Prerequisites]
- [Building the Prototype]
- [Running the Prototype]
- [System Functionalities]
- [User Roles]

Introduction
AgriEnergy-Part2 is a user-friendly C# application designed to help farmers list their products for sale efficiently. The intuitive interface allows farmers to categorize and manage their produce, which is securely stored in their profile within a database, ensuring data persistence. Administrators can access and manage all uploaded products with advanced filtering options. This README provides step-by-step instructions for setting up the development environment, building, and running the prototype, along with an overview of system functionalities and user roles.

Prerequisites
Before you begin, ensure you have the following software installed on your machine:
- [Visual Studio 2022](https://visualstudio.microsoft.com/vs/): Integrated development environment (IDE) for building the application.
- [.NET SDK](https://dotnet.microsoft.com/download): Required for developing and running the application.
- Git: For version control.

Steps:
1. Launch Visual Studio.
2. Select `File > Open > Project/Solution`.
3. Navigate to and select `AgriEnergy-Part2.sln`.
4. Restore NuGet packages:
   - In Visual Studio, right-click on the solution in the Solution Explorer.
   - Select `Restore NuGet Packages`.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Building the Prototype
----------------------
1. Select the build configuration:
   - In the toolbar, use the drop-down menu to select either `Debug` or `Release`.
2. Build the solution:
   - Click `Build > Build Solution` or press `Ctrl+Shift+B`.

Running the Prototype
---------------------
Run the application:
  - Ensure the AgriEnergy-Part2 project is set as the startup project (right-click the project in Solution Explorer and select `Set as StartUp Project`).
  - Click `Debug > Start Debugging` or press `F5` to run in Debug mode.
  - Alternatively, click `Debug > Start Without Debugging` or press `Ctrl+F5` to run without debugging.

System Functionalities
----------------------
1. Admin Profile Creation
Admins have the ability to create profiles for new farmers. This functionality is accessible through the "Register" button on the top-right corner of the navigation bar.

Steps:
1.1. Access the Register Page:
   - Click on the "Register" button located at the top-right corner of the navigation bar.
   
1.2. Input Farmer Information:
   - Email Enter the farmer's email address, which will be used as the username.
   - Password: Set a password for the farmer.
   - Confirm Password: Re-enter the password to confirm.
   - Role Designation: Select the role as "Farmer" from a dropdown menu or by clicking a designated checkbox.
   
1.3. Save Profile:
   - Click the "Create" button to save the new farmer profile.
   - The profile details are securely stored in the database.
   - Provide the farmer with their login credentials.

2. Farmer Dashboard
Upon logging in, farmers are directed to their personalized home page, equipped with a convenient navigation bar. Here, they can navigate to various sections such as "Products" and "Logout".

Features:
- Navigation Bar: Provides quick access to different sections of the dashboard.
- Products Section: Located at the top-left corner of the navigation bar.
- Logout Button: Located at the top-right corner for logging out of the session.

3. Product Management for Farmers
Farmers can manage their products through the "Products" section of their dashboard.

Steps:
3.1. Access Products Page:
   - Click on the "Products" button in the navigation bar.

3.2. Create New Product:
   - Click the "Create New" button.
   - Input Product Details:
     - Product Name: Enter the name of the product.
     - Production Date: Select the date when the product was produced.
     - Category: Type the category of the product into the input field.
   - Save Product: Click the "Create" button to store the product details in the database.

3.3. View Product Details:
   - Click the "Details" button on a product from the list to view its detailed information.
   - Details include product name, production date, and category.

3.4. Edit Product:
   - Click the "Edit" button next to the "Details" button.
   - Update the product details if needed.
   - Click "Save" to update the information in the database.

3.5. Delete Product:
   - Click the "Delete" button next to the "Edit" button.
   - Confirm the deletion to remove the product from the database.

4. Admin Product Management
Admins have comprehensive oversight of all products listed by farmers. They can access a unified products table inclusive of all farmer listings.

Features:
- Unified Products Table:
  - Displays all products listed by farmers.
  - Each product entry includes details such as product name, production date, category, and the respective farmer's ID.

- Filtering Options:
  - Date Range Filter: Filter products by specifying a start and end date of production.
  - Category Filter: Filter products by typing in the desired category.
  - Clear Filter: A button to clear the current filters and display the full list of products again.

Steps:
4.1. Access Admin Products Page:
   - Navigate to the "Products" tab from the admin dashboard.

4.2. Apply Filters:
   - Date Range Filter: Enter the start and end dates in the respective fields.
   - Category Filter: Enter the category in the filter input field.
   - Click the "Filter" button to apply the filters.

4.3. Clear Filters:
   - Click the "Clear Filter" button to remove all applied filters and view the full list of products.

4.4. View Product Details:**
   - Click on a product from the list to view detailed information, including the associated farmer's ID.

5. User Authentication and Authorization
Both admins and farmers have distinct roles with specific access permissions.

>Admin Role:
- Access to all functionalities, including creating farmer profiles and managing all products.
- Can view and filter all products listed by farmers.
- Can create, edit, and delete farmer profiles.

>Farmer Role:
- Limited access to functionalities.
- Can log in with credentials created by an admin.
- Can access the "Products" tab to create, edit, view, and delete their own product listings.
