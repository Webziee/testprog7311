namespace AgriEnergy_Part2.Models
{
    public class ErrorViewModel
    {
        // RequestId is used to uniquely identify a request and is nullable
        public string? RequestId { get; set; }

        // ShowRequestId returns true if RequestId is not null or empty
        // This can be used to determine if the RequestId should be displayed in the UI
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
