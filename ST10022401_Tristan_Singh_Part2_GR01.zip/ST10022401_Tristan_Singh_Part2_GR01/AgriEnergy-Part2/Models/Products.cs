﻿using System;

namespace AgriEnergy_Part2.Models
{
    public class Products
    {
        // Unique identifier for the product
        public Guid ID { get; set; }

        // Numeric product ID
        public int ProductId { get; set; }

        // Name of the product (nullable)
        public string? name { get; set; }

        // Category of the product
        public string Category { get; set; }

        // Date when the product was produced
        public DateTime productiondate { get; set; }

        // Identifier for the farmer who produced the product
        public string farmerID { get; set; }
    }
}
