﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AgriEnergy_Part2.Controllers
{
    // This controller manages roles and is restricted to users in the "admin" role
    [Authorize(Roles = "admin")]
    public class RolesController : Controller
    {
        private readonly RoleManager<IdentityRole> _manager;
        //private readonly UserManager<IdentityUser> _usermanager; // Uncomment if user manager is needed

        // Constructor with dependency injection for RoleManager and UserManager
        public RolesController(RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager)
        {
            _manager = roleManager;
            //_usermanager = userManager; // Uncomment if user manager is needed
        }

        // GET: Roles
        // Action method to display the list of roles
        public IActionResult Index()
        {
            var roles = _manager.Roles;
            return View(roles);
        }

        // GET: Roles/Create
        // Action method to display the create role form
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Roles/Create
        // Action method to handle the form submission for creating a new role
        [HttpPost]
        public IActionResult Create(IdentityRole role)
        {
            // Check if the role already exists
            if (!_manager.RoleExistsAsync(role.Name).GetAwaiter().GetResult())
            {
                // Create the new role
                _manager.CreateAsync(new IdentityRole(role.Name)).GetAwaiter().GetResult();
            }
            // Redirect to the index action
            return RedirectToAction("Index");
        }
    }
}
