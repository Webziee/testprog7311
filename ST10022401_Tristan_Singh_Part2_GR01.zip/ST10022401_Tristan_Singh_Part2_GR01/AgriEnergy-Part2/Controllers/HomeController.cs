using AgriEnergy_Part2.Data;
using AgriEnergy_Part2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims; // Add this namespace for LINQ operations

namespace AgriEnergy_Part2.Controllers
{
    // The HomeController is authorized for users in the "farmer" or "admin" roles
    [Authorize(Roles = "farmer, admin")]
    public class HomeController : Controller
    {
        // Private fields for logger and database context
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        // Constructor with dependency injection for logger and database context
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        // Action method for the Index page
        public IActionResult Index()
        {
            // Return the Index view
            return View();
        }

        // Action method for the Privacy page
        public IActionResult Privacy()
        {
            // Return the Privacy view
            return View();
        }

        // Action method for handling errors
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            // Return the Error view with a new ErrorViewModel
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
