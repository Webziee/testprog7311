﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AgriEnergy_Part2.Data;
using AgriEnergy_Part2.Models;
using System.Security.Claims;

namespace AgriEnergy_Part2.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Constructor with dependency injection for the database context
        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Product
        // Action method to display the list of products with optional filtering by date range and category
        public async Task<IActionResult> Index(DateTime? startDate, DateTime? endDate, string category)
        {
            // Start with a query for all products
            IQueryable<Products> productsQuery = _context.Products;

            // Filter by date range if start and end dates are provided
            if (startDate != null && endDate != null)
            {
                productsQuery = productsQuery.Where(p => p.productiondate >= startDate && p.productiondate <= endDate);
            }

            // Filter by category if provided
            if (!string.IsNullOrEmpty(category))
            {
                productsQuery = productsQuery.Where(p => p.Category == category);
            }

            // Get the role(s) of the currently logged-in user
            var userRoles = User.FindAll(ClaimTypes.Role).Select(r => r.Value);

            if (userRoles.Contains("admin"))
            {
                // Admin can see all products after applying filters
                var products = await productsQuery.ToListAsync();
                return View(products);
            }
            else
            {
                // Farmers can only see their own products
                string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value!;
                var products = await productsQuery.Where(p => p.farmerID == userId).ToListAsync();
                return View(products);
            }
        }

        // GET: Product/Details/5
        // Action method to display details of a specific product
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find the product by ID
            var products = await _context.Products
                .FirstOrDefaultAsync(m => m.ID == id);
            if (products == null)
            {
                return NotFound();
            }

            return View(products);
        }

        // GET: Product/Create
        // Action method to display the create product form
        public IActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        // Action method to handle the form submission for creating a new product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,ProductId,name,productiondate,farmerID,Category")] Products products)
        {
            // Set the farmer ID to the currently logged-in user's ID
            products.farmerID = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            if (ModelState.IsValid)
            {
                // Assign a new GUID for the product ID
                products.ID = Guid.NewGuid();
                _context.Add(products);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(products);
        }

        // GET: Product/Edit/5
        // Action method to display the edit form for a specific product
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find the product by ID
            var products = await _context.Products.FindAsync(id);
            if (products == null)
            {
                return NotFound();
            }
            return View(products);
        }

        // POST: Product/Edit/5
        // Action method to handle the form submission for editing a product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("ID,ProductId,name,productiondate,farmerID,Category")] Products products)
        {
            if (id != products.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Update the product in the database
                    _context.Update(products);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductsExists(products.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(products);
        }

        // GET: Product/Delete/5
        // Action method to display the delete confirmation page for a specific product
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find the product by ID
            var products = await _context.Products
                .FirstOrDefaultAsync(m => m.ID == id);
            if (products == null)
            {
                return NotFound();
            }

            return View(products);
        }

        // POST: Product/Delete/5
        // Action method to handle the form submission for deleting a product
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            // Find the product by ID
            var products = await _context.Products.FindAsync(id);
            if (products != null)
            {
                // Remove the product from the database
                _context.Products.Remove(products);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // Helper method to check if a product exists by ID
        private bool ProductsExists(Guid id)
        {
            return _context.Products.Any(e => e.ID == id);
        }
    }
}
