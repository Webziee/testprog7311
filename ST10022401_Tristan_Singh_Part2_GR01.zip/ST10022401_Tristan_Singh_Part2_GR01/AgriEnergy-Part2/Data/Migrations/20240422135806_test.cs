﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AgriEnergy_Part2.Data.Migrations
{
    /// <inheritdoc />
    public partial class test : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
               name: "Products",
               columns: table => new
               {
                   ID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                   ProductId = table.Column<int>(type: "int", nullable: false),
                   name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                   MyProperty = table.Column<string>(type: "nvarchar(max)", nullable: true),
                   production_date = table.Column<string>(type: "nvarchar(max)", nullable: true)
               },
               constraints: table =>
               {
                   table.PrimaryKey("PK_Products", x => x.ID);
               });

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
               name: "Products");
        }
    }
}
