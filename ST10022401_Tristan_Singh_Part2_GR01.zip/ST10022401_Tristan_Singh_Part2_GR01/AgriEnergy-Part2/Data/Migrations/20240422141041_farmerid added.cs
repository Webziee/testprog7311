﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AgriEnergy_Part2.Data.Migrations
{
    /// <inheritdoc />
    public partial class farmeridadded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MyProperty",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "production_date",
                table: "Products");

            migrationBuilder.AddColumn<int>(
                name: "farmerID",
                table: "Products",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "farmerID",
                table: "Products");

            migrationBuilder.AddColumn<string>(
                name: "MyProperty",
                table: "Products",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "production_date",
                table: "Products",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
