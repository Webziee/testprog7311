using AgriEnergy_Part2.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Get the connection string from the configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// Configure Entity Framework to use SQL Server with the connection string
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// Add database exception filter for development environment
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Configure Identity services with default UI, token providers, and entity framework stores
builder.Services.AddIdentity<IdentityUser, IdentityRole>(options => options.SignIn.RequireConfirmedAccount = false)
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultUI()
    .AddDefaultTokenProviders();

// Add MVC controllers with views support
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline based on the environment
if (app.Environment.IsDevelopment())
{
    // Use migration endpoint in development
    app.UseMigrationsEndPoint();
}
else
{
    // Use exception handler in production
    app.UseExceptionHandler("/Home/Error");
    // Use HSTS (HTTP Strict Transport Security) in production
    app.UseHsts();
}

// Use HTTPS redirection
app.UseHttpsRedirection();
// Serve static files
app.UseStaticFiles();

app.UseRouting();

// Use authentication and authorization
app.UseAuthentication();
app.UseAuthorization();

// Map controller routes
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Map Razor Pages
app.MapRazorPages();

// Run the application
app.Run();


// CODE ATTRIBUTION 
//-----------------//
//ASP.NET CORE Identity Authentication and Authorization in ASP Net Core Login and Registration. 2023. YouTube video, added by Macro Code. [Online]. Available at:
//https://www.youtube.com/watch?v=pzyCGb1T7I8&list=PLzMTA6dX_CDfC-joBr7xQmCmVKFpyrYay&index=4 [Accessed 18 April 2024]

//ASP.NET MVC Tutorials - Implement Search Functionality in ASP.NET MVC.. 2023. YouTube video, added by NetCode Hub. [Online]. Available at:
//https://www.youtube.com/watch?v=bzWJOxBR-MY&list=PLzMTA6dX_CDfC-joBr7xQmCmVKFpyrYay&index=5 [Accessed 22 April 2024]

//ASP.NET Core 7.0 Role Based Authorization || How to Implement Roles Based Authorization. 2023. YouTube video, added by Macro Code. [Online]. Available at:
//https://www.youtube.com/watch?v=VZgxKbAdbbo&list=PLzMTA6dX_CDfC-joBr7xQmCmVKFpyrYay&index=3 [Accessed 19 April 2024]

//ASP.NET MVC - How To Implement Role Based Authorization. 2023. YouTube video, added by Digital TechJoint. [Online]. Available at:
//https://www.youtube.com/watch?v=qvsWwwq2ynE&list=PLzMTA6dX_CDfC-joBr7xQmCmVKFpyrYay&index=2 [Accessed 18 April 2024]

//Stack Overflow. 2014. Filtering data inside .NET core controllers.
//[Online]. Available at: https://stackoverflow.com/questions/63282719/filtering-data-inside-net-core-controllers [Accessed 22 November 2015].
